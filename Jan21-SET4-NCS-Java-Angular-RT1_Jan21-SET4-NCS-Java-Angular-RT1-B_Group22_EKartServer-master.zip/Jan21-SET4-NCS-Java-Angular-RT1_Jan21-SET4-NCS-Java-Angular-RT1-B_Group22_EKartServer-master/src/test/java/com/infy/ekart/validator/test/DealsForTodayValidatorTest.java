package com.infy.ekart.validator.test;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.infy.ekart.dto.DealForTodayDTO;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.validator.DealsForTodayValidator;

public class DealsForTodayValidatorTest {

	@Test
	void validateDateInvalidTest() throws EKartException{
	    DealForTodayDTO d=new DealForTodayDTO();
	    d.setDealStart(LocalDateTime.now());
	    d.setDealEnd(LocalDateTime.now().minusDays(1));
	    Exception exception = Assertions.assertThrows(EKartException.class,() -> DealsForTodayValidator.validate(d));
	    Assertions.assertEquals("DealForTodayService.INVALID_DATE_DETAILS", exception.getMessage());
	}
	@Test
	void validateDateValidTest() throws EKartException{
	    DealForTodayDTO d=new DealForTodayDTO();
	    d.setDealStart(LocalDateTime.now());
	    d.setDealEnd(LocalDateTime.now());
	    Assertions.assertEquals(true,DealsForTodayValidator.validateDate(d) );
	}
	
	@Test
	void validateTimeInvalidTest() throws EKartException{
		DealForTodayDTO d=new DealForTodayDTO();
		d.setDealStart(LocalDateTime.now().withHour(3));
		d.setDealEnd(LocalDateTime.now().withHour(1));
		Exception exception = Assertions.assertThrows(EKartException.class,() -> DealsForTodayValidator.validate(d));
		Assertions.assertEquals("DealForTodayService.INVALID_TIME_DETAILS", exception.getMessage());
	}
	@Test
	void validateTimeValidTest() throws EKartException{
	    DealForTodayDTO d=new DealForTodayDTO();
	    d.setDealStart(LocalDateTime.now().withHour(1));
	    d.setDealEnd(LocalDateTime.now().withHour(5));
	    Assertions.assertEquals(true,DealsForTodayValidator.validateTime(d) );
	}
}
