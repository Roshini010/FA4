package com.infy.ekart.service.test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.infy.ekart.dto.DealForTodayDTO;
import com.infy.ekart.dto.ProductDTO;
import com.infy.ekart.dto.SellerDTO;
import com.infy.ekart.entity.DealForToday;
import com.infy.ekart.entity.Product;
import com.infy.ekart.entity.Seller;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.repository.DealForTodayRepository;
import com.infy.ekart.repository.ProductRepository;
import com.infy.ekart.repository.SellerRepository;
import com.infy.ekart.service.DealForTodayService;
import com.infy.ekart.service.DealForTodayServiceImpl;

@SpringBootTest
public class DealForTodayServiceTest {
	
    @Mock
    private DealForTodayRepository dealsForTodayRepository;

    @Mock
    private SellerRepository sellerRepository;

    @Mock
    private ProductRepository productRepository;

    @InjectMocks
    private DealForTodayService dealsForTodayService = new DealForTodayServiceImpl();

    //DealsForTodayService Test Cases

    //Test1 for user story-1

    @Test
    void addProductToDealsForTodayInvalidSellerTest() throws EKartException
   {
	DealForTodayDTO dealsForTodayDTO= new DealForTodayDTO();
	SellerDTO sellerDTO=new SellerDTO();
	sellerDTO.setEmailId("xyz@infosys.com");
	dealsForTodayDTO.setSeller(sellerDTO);
	Mockito.when(sellerRepository.findById(Mockito.anyString())).thenReturn(Optional.empty());
	EKartException eKartException=Assertions.assertThrows(EKartException.class,()-> dealsForTodayService.addProductToDeal(dealsForTodayDTO));
	Assertions.assertEquals("Service.SELLER_NOT_FOUND", eKartException.getMessage());
   }
    @Test
    void addproductToDealValidSellerTest() throws EKartException{
    	DealForTodayDTO dealsForTodayDTO= new DealForTodayDTO();
    	SellerDTO sellerDTO=new SellerDTO();
    	sellerDTO.setEmailId("jack@infosys.com");
    	ProductDTO p=new ProductDTO();
    	p.setProductId(1001);
    	dealsForTodayDTO.setDealStart(LocalDateTime.now().withHour(1));
    	dealsForTodayDTO.setDealEnd(LocalDateTime.now().withHour(3));
    	dealsForTodayDTO.setSeller(sellerDTO);
    	dealsForTodayDTO.setProduct(p);
    	Seller s=new Seller();
    	s.setEmailId("jack@infosys.com");
    	Product po=new Product();
    	po.setProductId(1001);
    	DealForToday d=new DealForToday();
    	d.setSeller(s);
    	d.setProduct(po);
        d.setDealDiscount(dealsForTodayDTO.getDealDiscount());	
        Mockito.when(sellerRepository.findById(dealsForTodayDTO.getSeller().getEmailId())).thenReturn(Optional.of(s));
        Mockito.when(productRepository.findById(dealsForTodayDTO.getProduct().getProductId())).thenReturn(Optional.of(po));
        Mockito.when(dealsForTodayRepository.save(Mockito.any())).thenReturn(d);
      Assertions.assertEquals(po.getProductId(),dealsForTodayService.addProductToDeal(dealsForTodayDTO));
    }
   @Test
   void getProductsNotInDealInvalidTest() throws EKartException{
	   Pageable pageable = PageRequest.of(2,10);
	   Mockito.when(dealsForTodayRepository.findProductNotInDeal("xyz@infosys.com",pageable)).thenReturn(Collections.emptyList());
	   EKartException e=Assertions.assertThrows(EKartException.class,()->dealsForTodayService.getProductsNotInDeal("xyz@infosys.com", 2));
	   Assertions.assertEquals("DealForTodayService.PRODUCT.NOT.FOUND",e.getMessage());
   }
   @Test
   void getProductsNotInDealValidTest() throws EKartException{
	   List<Product> l=new ArrayList<>();
	   Product p=new Product();
	   p.setName("Jack");
	   l.add(p);
	   Pageable pageable = PageRequest.of(0,10);
	   Mockito.when(dealsForTodayRepository.findProductNotInDeal("jack@infosys.com",pageable)).thenReturn(l);
	   Assertions.assertNotNull(dealsForTodayService.getProductsNotInDeal("jack@infosys.com", 0));
   }
   @Test
   void getDealForTodayInvalidTest() throws EKartException{
    Pageable pageable = PageRequest.of(2,10);
    Mockito.when(dealsForTodayRepository.findBySellerEmailId("xyz@infosys.com",pageable)).thenReturn(Collections.emptyList());
    EKartException e=Assertions.assertThrows(EKartException.class,()->dealsForTodayService.getDealForToday("jack@infosys.com",1));
    Assertions.assertEquals("DealForTodayService.NO_PRODUCT_ADDED_TO_DEAL",e.getMessage());
   }
  @Test
  void getDealForTodayValidTest() throws EKartException{
	List<DealForToday> deal=new ArrayList<>();
	DealForToday d=new DealForToday();
	d.setDealId(2);
	Seller s=new Seller();
	s.setEmailId("jack@infosys.com");
	d.setSeller(s);
	Product p =new Product();
	p.setProductId(3);
	d.setProduct(p);
	deal.add(d);
	Pageable pageable = PageRequest.of(1,10);
	Mockito.when(dealsForTodayRepository.findBySellerEmailId("jack@infosys.com",pageable)).thenReturn(deal);
	Assertions.assertTrue(!(dealsForTodayService.getDealForToday("jack@infosys.com", 1).isEmpty()));
  }
  
  // User Story 3 Test Cases
  @Test
  void deleteProductFromDealInvalidTest() throws EKartException{
     DealForTodayDTO d=new DealForTodayDTO();
     d.setDealId(501050);
     Mockito.when(dealsForTodayRepository.findById(d.getDealId())).thenReturn(Optional.empty());
     EKartException eKartException=Assertions.assertThrows(EKartException.class,()-> dealsForTodayService.deleteProductFromDeal(d.getDealId()));
     Assertions.assertEquals("Service.DEAL_NOT_FOUND", eKartException.getMessage());
  }
  @Test
  void deleteProductFromDealValidTest() throws EKartException{
	  DealForToday d=new DealForToday();
	  d.setDealId(1);
	  Mockito.when(dealsForTodayRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(d));
	  Assertions.assertEquals(d.getDealId(),dealsForTodayService.deleteProductFromDeal(d.getDealId()));
  }
  
  // User story 4 Test cases
   @Test
   void getAllDealForTodayInvalidTest() throws EKartException{
	Pageable pageable = PageRequest.of(1,10);
	 LocalDateTime dealStart= LocalDateTime.of(LocalDate.now(), LocalTime.of(0,0,0));
	 LocalDateTime dealEnd= LocalDateTime.of(LocalDate.now().plusDays(1), LocalTime.of(0,0,0));
	List<DealForToday> dlist=new ArrayList<>();
	Mockito.when(dealsForTodayRepository.findByDealStartDate(dealStart, dealEnd, pageable)).thenReturn(dlist);
	EKartException e=Assertions.assertThrows(EKartException.class,()->dealsForTodayService.getAllDealForToday(1));
	Assertions.assertEquals("DealForTodayService.DEALS.ARE.NOT.FOUND",e.getMessage());
   }
   @Test
   void getAllDealForTodayValidTest() throws EKartException{
	   Pageable pageable = PageRequest.of(1,10);
	   LocalDateTime dealStart= LocalDateTime.of(LocalDate.now(), LocalTime.of(0,0,0));
	   LocalDateTime dealEnd= LocalDateTime.of(LocalDate.now().plusDays(1), LocalTime.of(0,0,0));
	   List<DealForToday> dlist=new ArrayList<>();
	   DealForToday d=new DealForToday();
	   d.setDealId(1);
	   LocalDateTime sDate=LocalDateTime.now().minusDays(1);
	   LocalDateTime eDate=LocalDateTime.now().plusDays(1);
	   d.setDealStart(sDate);
	   d.setDealEnd(eDate);
	   Seller s=new Seller();
	   s.setEmailId("brad@infosys.com");
	   d.setSeller(s);
	   Product p=new Product();
	   p.setProductId(2);
	   d.setProduct(p);
	   dlist.add(d);
	   Mockito.when(dealsForTodayRepository.findByDealStartDate(dealStart, dealEnd, pageable)).thenReturn(dlist);
	   Assertions.assertNotNull(dealsForTodayService.getAllDealForToday(1));
   }
   
}

