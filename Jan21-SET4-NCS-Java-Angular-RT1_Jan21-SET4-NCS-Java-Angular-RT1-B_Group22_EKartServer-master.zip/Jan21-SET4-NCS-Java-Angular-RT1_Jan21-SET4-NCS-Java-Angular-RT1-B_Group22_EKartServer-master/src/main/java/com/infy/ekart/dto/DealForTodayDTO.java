package com.infy.ekart.dto;

import java.time.LocalDateTime;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

public class DealForTodayDTO {
	    
		private Integer dealId;
		@NotNull(message="{product.is.not.present}")
		@Valid
		private ProductDTO product;
		@NotNull(message="{dealDiscount.is.not.present}")
		private double dealDiscount;
		@NotNull(message="{startdatetime.is.not.present}")
		private LocalDateTime dealStart;
		@NotNull(message="{enddatetime.is.not.present}")
		private LocalDateTime dealEnd;
		@NotNull(message="{Seller.is.not.present}")
		@Valid
		private SellerDTO seller;
		private String successMessage;
		private String errorMessage;
		private String statusMessage;
		public String getStatusMessage() {
			return statusMessage;
		}
		public void setStatusMessage(String statusMessage) {
			this.statusMessage = statusMessage;
		}
		public Integer getDealId() {
			return dealId;
		}
		public void setDealId(Integer dealId) {
			this.dealId = dealId;
		}
		public ProductDTO getProduct() {
			return product;
		}
		public void setProduct(ProductDTO product) {
			this.product = product;
		}
		public double getDealDiscount() {
			return dealDiscount;
		}
		public void setDealDiscount(double dealDiscount) {
			this.dealDiscount = dealDiscount;
		}
		public LocalDateTime getDealStart() {
			return dealStart;
		}
		public void setDealStart(LocalDateTime dealStart) {
			this.dealStart = dealStart;
		}
		public LocalDateTime getDealEnd() {
			return dealEnd;
		}
		public void setDealEnd(LocalDateTime dealEnd) {
			this.dealEnd = dealEnd;
		}
		public SellerDTO getSeller() {
			return seller;
		}
		public void setSeller(SellerDTO seller) {
			this.seller = seller;
		}
		public String getSuccessMessage() {
			return successMessage;
		}
		public void setSuccessMessage(String successMessage) {
			this.successMessage = successMessage;
		}
		public String getErrorMessage() {
			return errorMessage;
		}
		public void setErrorMessage(String errorMessage) {
			this.errorMessage = errorMessage;
		}
		
		

}
