package com.infy.ekart.service;

import java.util.List;

import com.infy.ekart.dto.DealForTodayDTO;
import com.infy.ekart.dto.ProductDTO;
import com.infy.ekart.exception.EKartException;

public interface DealForTodayService {
	Integer addProductToDeal(DealForTodayDTO dealForToday) throws EKartException;
	List<DealForTodayDTO> getDealForToday(String sellerEmailId,Integer pageNo) throws EKartException ;
	List<ProductDTO> getProductsNotInDeal(String sellerEmailId,Integer pageNo) throws EKartException;
	Integer deleteProductFromDeal(Integer dealId) throws EKartException;
	List<DealForTodayDTO> getAllDealForToday(Integer pageNo) throws EKartException;
}
