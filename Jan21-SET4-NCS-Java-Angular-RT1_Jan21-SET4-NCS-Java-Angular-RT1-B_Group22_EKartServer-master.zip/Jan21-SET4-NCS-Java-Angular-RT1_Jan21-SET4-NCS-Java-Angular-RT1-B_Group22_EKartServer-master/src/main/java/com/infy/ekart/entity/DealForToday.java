package com.infy.ekart.entity;

import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="EK_DEALS_FOR_TODAY")
public class DealForToday {

    @Id
    @Column(name="DEAL_ID")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer dealId;
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="PRODUCT_ID",unique = true)
    private Product product;
    @Column(name="DEAL_DISCOUNT")
    private double dealDiscount;
    @Column(name="DEAL_STARTS_AT")
    private LocalDateTime dealStart;
    @Column(name="DEAL_ENDS_AT")
    private LocalDateTime dealEnd;
    @ManyToOne(cascade =CascadeType.ALL )
    @JoinColumn(name="SELLER_EMAIL_ID")
    private Seller seller;
	public Integer getDealId() {
		return dealId;
	}
	public void setDealId(Integer dealId) {
		this.dealId = dealId;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public double getDealDiscount() {
		return dealDiscount;
	}
	public void setDealDiscount(double dealDiscount) {
		this.dealDiscount = dealDiscount;
	}
	public LocalDateTime getDealStart() {
		return dealStart;
	}
	public void setDealStart(LocalDateTime dealStart) {
		this.dealStart = dealStart;
	}
	public LocalDateTime getDealEnd() {
		return dealEnd;
	}
	public void setDealEnd(LocalDateTime dealEnd) {
		this.dealEnd = dealEnd;
	}
	public Seller getSeller() {
		return seller;
	}
	public void setSeller(Seller seller) {
		this.seller = seller;
	}
    
    
    
          
}
