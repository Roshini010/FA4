package com.infy.ekart.api;

import java.util.List;

import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.ekart.dto.DealForTodayDTO;
import com.infy.ekart.dto.ProductDTO;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.service.DealForTodayService;

@CrossOrigin
@RestController
@RequestMapping(value = "/dealForToday-api")
@Validated
public class DealForTodayAPI {
	@Autowired
	private DealForTodayService dealForTodayService ;
	
	@Autowired
	private Environment environment;
	
	static Log logger = LogFactory.getLog(DealForTodayAPI.class);
//us1
	
	@PostMapping(value = "/dealForToday")
	public ResponseEntity<DealForTodayDTO> addProductToDeal(@RequestBody @Valid DealForTodayDTO dealForTodayDTO) throws EKartException {
		Integer id=dealForTodayService.addProductToDeal(dealForTodayDTO);
		String msg=environment.getProperty("DealForTodayAPI.PRODUCT_ADDED_TO_DEAL")+" with id: "+id;
		dealForTodayDTO.setSuccessMessage(msg);
		return new ResponseEntity<>(dealForTodayDTO,HttpStatus.OK);
        }
	@GetMapping(value= "/ProductsNotIndealForToday/{sellerEmailId}/{pageNo}")
	public ResponseEntity<List<ProductDTO>> getProductsNotInDeal(@PathVariable String sellerEmailId,@PathVariable Integer pageNo )throws EKartException{
		return new ResponseEntity<>(dealForTodayService.getProductsNotInDeal(sellerEmailId,pageNo),HttpStatus.OK);
	}
	
	
//us2
	@GetMapping(value= "/dealForToday/{sellerEmailId}/{pageNo}")
	public ResponseEntity<List<DealForTodayDTO>> getDealForToday(@PathVariable String sellerEmailId,@PathVariable Integer pageNo )throws EKartException{
		return new ResponseEntity<>(dealForTodayService.getDealForToday(sellerEmailId,pageNo),HttpStatus.OK);
	}
	
	
//us3	
	@DeleteMapping(value="/dealForToday/{dealId}")
	public ResponseEntity<String> deleteProductFromDeal(@PathVariable("dealId") Integer dealId) throws EKartException {
		Integer id=dealForTodayService.deleteProductFromDeal(dealId);
		String msg=environment.getProperty("DealForTodayAPI.PRODUCT_DELETED_FROM_DEAL")+" with DealId: "+id;
		return new ResponseEntity<>(msg,HttpStatus.OK);
	}
	
	
//us4
	@GetMapping(value= "/dealForToday/{pageNo}")
	public ResponseEntity<List<DealForTodayDTO>> getAllDealForToday(@PathVariable Integer pageNo)throws EKartException{
		return new ResponseEntity<>(dealForTodayService.getAllDealForToday(pageNo),HttpStatus.OK);
	}
	
	

}
