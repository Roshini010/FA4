package com.infy.ekart.repository;

import org.springframework.data.repository.CrudRepository;

import com.infy.ekart.entity.Address;

public interface AddressRepository extends CrudRepository<Address, Integer> {

}
