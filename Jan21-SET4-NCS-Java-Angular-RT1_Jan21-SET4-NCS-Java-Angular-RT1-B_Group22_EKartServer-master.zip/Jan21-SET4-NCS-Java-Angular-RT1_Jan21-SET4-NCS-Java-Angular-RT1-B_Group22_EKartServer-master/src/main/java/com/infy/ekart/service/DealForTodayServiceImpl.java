package com.infy.ekart.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.ekart.dto.DealForTodayDTO;
import com.infy.ekart.dto.ProductDTO;
import com.infy.ekart.dto.SellerDTO;
import com.infy.ekart.entity.DealForToday;
import com.infy.ekart.entity.Product;
import com.infy.ekart.entity.Seller;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.repository.DealForTodayRepository;
import com.infy.ekart.repository.ProductRepository;
import com.infy.ekart.repository.SellerRepository;
import com.infy.ekart.validator.DealsForTodayValidator;


@Service(value = "dealForTodayService")
@Transactional
public class DealForTodayServiceImpl implements DealForTodayService{

	@Autowired
	private DealForTodayRepository dealForTodayRepository;

	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private SellerRepository sellerRepository;

	//this method adds new product to deal
	@Override
	public Integer addProductToDeal(DealForTodayDTO dealForToday) throws EKartException {
		Optional<Seller> optionalSeller = sellerRepository.findById(dealForToday.getSeller().getEmailId());
    	Seller seller = optionalSeller.orElseThrow(() -> new EKartException("Service.SELLER_NOT_FOUND"));
    	Optional<Product> optionalProduct = productRepository.findById(dealForToday.getProduct().getProductId());
    	Product product = optionalProduct.orElseThrow(() -> new EKartException("Service.PRODUCT_NOT_FOUND"));
    	DealsForTodayValidator.validate(dealForToday);
		DealForToday dft=new DealForToday();
		dft.setDealDiscount(dealForToday.getDealDiscount());
		dft.setDealEnd(dealForToday.getDealEnd());
		dft.setDealStart(dealForToday.getDealStart());
    	dft.setProduct(product);
    	dft.setSeller(seller);
    	dealForTodayRepository.save(dft);
    	return dft.getProduct().getProductId();
      }

	//us1
	@Override
	public List<ProductDTO> getProductsNotInDeal(String sellerEmailId,Integer pageNo) throws EKartException{
		Pageable p=PageRequest.of(pageNo,10);
		List<Product> po=dealForTodayRepository.findProductNotInDeal(sellerEmailId, p);
		if(po==null||po.isEmpty()) {
			throw new EKartException("DealForTodayService.PRODUCT.NOT.FOUND");
		}
		List<ProductDTO> product=new ArrayList<>();
		for(Product pro:po) {
					ProductDTO productDTO = new ProductDTO();
					productDTO.setProductId(pro.getProductId());
					productDTO.setBrand(pro.getBrand());
					productDTO.setName(pro.getName());
					productDTO.setDescription(pro.getDescription());
					productDTO.setCategory(pro.getCategory());
					productDTO.setPrice(pro.getPrice());
					productDTO.setDiscount(pro.getDiscount());
					productDTO.setQuantity(pro.getQuantity());
					productDTO.setSellerEmailId(pro.getEmailId());
					product.add(productDTO);
				}
			return product;
	}
	
	
	//us2
    @Override
    public List<DealForTodayDTO> getDealForToday(String sellerEmailId,Integer pageNo) throws EKartException {
    	Pageable p=PageRequest.of(pageNo,10);
    	List<DealForToday> deal=dealForTodayRepository.findBySellerEmailId(sellerEmailId,p);
    	if (deal == null || deal.isEmpty()) {
    		throw new EKartException("DealForTodayService.NO_PRODUCT_ADDED_TO_DEAL");
    	}
    	List<DealForTodayDTO> deals=new ArrayList<>();
    	for(DealForToday d:deal)
    	{
    	   DealForTodayDTO da = new DealForTodayDTO();
    	   da.setDealId(d.getDealId());
    	   da.setDealStart(d.getDealStart());
    	   da.setDealEnd(d.getDealEnd());
    	   da.setDealDiscount(d.getDealDiscount());
    	   Product product = d.getProduct();
    	   ProductDTO productDTO = new ProductDTO();
		   productDTO.setBrand(product.getBrand());
		   productDTO.setCategory(product.getCategory());
		   productDTO.setDescription(product.getDescription());
		   productDTO.setDiscount(product.getDiscount());
		   productDTO.setName(product.getName());
		   productDTO.setPrice(product.getPrice());
		   productDTO.setProductId(product.getProductId());
		   productDTO.setQuantity(product.getQuantity());
		   productDTO.setSuccessMessage("Success");
		   productDTO.setErrorMessage("Error");
		   productDTO.setSellerEmailId(product.getEmailId());
    	   da.setProduct(productDTO);
    	   Seller se=d.getSeller();
    	   SellerDTO s=new SellerDTO();
    	   s.setEmailId(se.getEmailId());
    	   s.setName(se.getName());
    	   s.setPassword(se.getPassword());
    	   s.setPhoneNumber(se.getPhoneNumber());
    	   s.setAddress(se.getAddress());
    	   s.setErrorMessage("Error");
    	   da.setSeller(s);
    	   deals.add(da);
    	  
    	}

    	return deals;
    }
    
   
    //us3
   @Override
   public Integer deleteProductFromDeal(Integer dealId) throws EKartException{
	   Optional<DealForToday> dft=dealForTodayRepository.findById(dealId);
	   DealForToday d=dft.orElseThrow(() -> new EKartException("Service.DEAL_NOT_FOUND"));
	   d.setProduct(null);
	   d.setSeller(null);
	   Integer deleteId=d.getDealId();
	   dealForTodayRepository.delete(d);
	   return deleteId;
   }
   
  
   
   //us4
   @Override
   public List<DealForTodayDTO> getAllDealForToday(Integer pageNo) throws EKartException{
	   Pageable p=PageRequest.of(pageNo,10);
	   LocalDateTime dealStart= LocalDateTime.of(LocalDate.now(), LocalTime.of(0,0,0));
	   LocalDateTime dealEnd= LocalDateTime.of(LocalDate.now().plusDays(1), LocalTime.of(0,0,0));
	  
	   List<DealForToday> deal=dealForTodayRepository.findByDealStartDate(dealStart, dealEnd, p);
	   
	   if (deal == null || deal.isEmpty()) {
   		throw new EKartException("DealForTodayService.DEALS.ARE.NOT.FOUND");
     	}
	   List<DealForTodayDTO> deals=new ArrayList<>();
   	   for(DealForToday d:deal)
   	   {
   	   DealForTodayDTO da = new DealForTodayDTO();
   	   da.setDealId(d.getDealId());
   	   da.setDealStart(d.getDealStart());
   	   da.setDealEnd(d.getDealEnd());
   	   da.setDealDiscount(d.getDealDiscount());
   	   Product product = d.getProduct();
   	   ProductDTO productDTO = new ProductDTO();
	   productDTO.setBrand(product.getBrand());
	   productDTO.setCategory(product.getCategory());
	   productDTO.setDescription(product.getDescription());
	   productDTO.setDiscount(product.getDiscount());
	   productDTO.setName(product.getName());
	   productDTO.setPrice(product.getPrice());
	   productDTO.setProductId(product.getProductId());
	   productDTO.setQuantity(product.getQuantity());
	   productDTO.setSuccessMessage("Success");
	   productDTO.setErrorMessage("Error");
	   productDTO.setSellerEmailId(product.getEmailId());
   	   da.setProduct(productDTO);
   	   Seller se=d.getSeller();
   	   SellerDTO s=new SellerDTO();
   	   s.setEmailId(se.getEmailId());
   	   s.setName(se.getName());
   	   s.setPhoneNumber(se.getPhoneNumber());
   	   s.setAddress(se.getAddress());
   	   s.setErrorMessage("Error");
   	   da.setSeller(s);
   	   deals.add(da);
   	   }
   	   return deals;
   	   
   }

}

