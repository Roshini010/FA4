package com.infy.ekart.validator;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.infy.ekart.dto.DealForTodayDTO;
import com.infy.ekart.exception.EKartException;

public class DealsForTodayValidator {
	public static void validate(DealForTodayDTO dealForToday) throws EKartException{
		if(!DealsForTodayValidator.validateDate(dealForToday)) {
			throw new EKartException("DealForTodayService.INVALID_DATE_DETAILS");
		}
		if(!DealsForTodayValidator.validateTime(dealForToday)) {
			throw new EKartException("DealForTodayService.INVALID_TIME_DETAILS");
		}
	}
	
	public static boolean validateDate(DealForTodayDTO dealForToday) {
		LocalDateTime startD=dealForToday.getDealStart();
		LocalDateTime dealE=dealForToday.getDealEnd();
		if(startD.toLocalDate().isAfter(dealE.toLocalDate()) || startD.toLocalDate().isBefore(dealE.toLocalDate())) {
			return false;
		}
		if(startD.toLocalDate().isAfter(LocalDate.now().plusMonths(1)) || startD.toLocalDate().isBefore(LocalDate.now())) {
			return false;
		}
		return true;
	}
	
	public static boolean validateTime(DealForTodayDTO dealForToday) {
		LocalDateTime startD=dealForToday.getDealStart();
		LocalDateTime dealE=dealForToday.getDealEnd();
		if(dealE.toLocalTime().isBefore(startD.toLocalTime())) {
			return false;
		}
		return true;
	}
}
