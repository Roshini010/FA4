package com.infy.ekart.repository;

import java.time.LocalDateTime;
import java.util.List;


import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.infy.ekart.entity.DealForToday;
import com.infy.ekart.entity.Product;

public interface DealForTodayRepository extends CrudRepository<DealForToday, Integer> {

	
	
	@Query("Select p from Product p where p.emailId=?1 and p.productId not in(select d.product.productId from DealForToday d where d.seller.emailId=?1)")
	List<Product> findProductNotInDeal(String sellerEmailId,Pageable pageable);
	
	List<DealForToday> findBySellerEmailId (String sellerEmailId,Pageable pageable);
	
	@Query("Select d from DealForToday d where d.dealStart >= ?1 And d.dealEnd <= ?2")
	List<DealForToday> findByDealStartDate(LocalDateTime startDate, LocalDateTime endDate, Pageable page);

}
