import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Observable, throwError } from 'rxjs';
import { DealsForToday } from 'src/app/shared/models/deals';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class CustomerDealsService {
  constructor(private http: HttpClient) { }
  
  getDealsForToday(pageNo): Observable<DealsForToday[]> {
    const url = environment.DealsForTodayAPI + "/dealForToday/"+pageNo;
   
    return this.http.get<DealsForToday[]>(url);
}
 
}
