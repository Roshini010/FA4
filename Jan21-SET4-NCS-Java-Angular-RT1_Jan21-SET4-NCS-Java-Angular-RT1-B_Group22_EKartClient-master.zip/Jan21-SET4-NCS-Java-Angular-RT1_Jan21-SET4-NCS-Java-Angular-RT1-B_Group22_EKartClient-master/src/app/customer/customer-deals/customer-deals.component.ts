import { Component, OnInit } from '@angular/core';
import { DealsForToday } from 'src/app/shared/models/deals';
import { CustomerDealsService } from './customer-deals.service';

@Component({
  selector: 'app-customer-deals',
  templateUrl: './customer-deals.component.html',
  styleUrls: ['./customer-deals.component.css']
})
export class CustomerDealsComponent implements OnInit {

  successMessage: string;
  errorMessage: string;
  dealList:DealsForToday[];
  addedDeal:DealsForToday;
  pageNo:number=0;
  dealListLength:number;

  currentDate:Date=new Date();
  currentDtime:number;
  dateS:String;
  date:String;
  dateMonth:String;
  dateYear:String;
  dateHour:String;
  dateMinute:String;
  dateArr:String[];
  dstartDate:String;
  dEndDate:String;
  dStartTime:any;
  dEndTime:any;
  
  dealDisplay:boolean;
  isNotStart:boolean;
  isStart:boolean;
  isEnd:boolean;
  display:boolean=true;
  page:boolean;

  

  constructor(private customerDealsService: CustomerDealsService) { }

  ngOnInit(): void {
    this.getAllDeals();
}
getAllDeals(){
  this.customerDealsService.getDealsForToday(this.pageNo).subscribe(
    deals=>{
      this.dealList=deals;
      this.dealListLength=this.dealList.length;
    }
  )

}

checkDealDate(startD:Date, endDate:Date):String
{
  this.dstartDate=startD.toString();
  this.dateArr=this.dstartDate.split(",");
  this.dStartTime=this.dateArr[3];

  this.dEndDate=endDate.toString();
  this.dateArr=this.dEndDate.split(",");
  this.dEndTime=this.dateArr[3];

  this.currentDtime=this.currentDate.getHours();

  if(this.currentDtime<this.dStartTime){
    this.isNotStart=true;
    this.isEnd=false;
    this.isStart=false;
    return "Deal Yet To Start";
  }
  else if(this.currentDtime>this.dEndTime){
    this.isNotStart=false;
    this.isEnd=true;
    this.isStart=false;
    return "Deal Ended";
  }
  else{
    this.isEnd=false;
    this.isStart=true;
    this.isNotStart=false
    return "Deal is On";
  }
}

toNextPage(){
  if(this.dealListLength==10){
    this.page=true;
    this.pageNo+=1;
    this.getAllDeals();
  }

}

toPreviousPage(){
  if(this.pageNo>0){
    this.pageNo-=1;
    this.getAllDeals();

  }
}

selectDeal(deal:DealsForToday){
  this.dealDisplay=true;
  this.display=false;
  this.addedDeal=deal;
}

toBack(){
  this.dealDisplay=false;
  this.display=true;
}

dateTimeFormat(formatDate:Date):any{
  this.dateS=formatDate.toString();
  this.dateArr=this.dateS.split(",");
  this.date=this.dateArr[2];
  this.dateMonth=this.dateArr[1];
  this.dateYear=this.dateArr[0];
  this.dateHour=this.dateArr[3];
  this.dateMinute=this.dateArr[4];

  return(this.date+"/"+this.dateMonth+"/"+this.dateYear+" "+this.dateHour+":"+this.dateMinute);

}
}

