import { Product } from './product';
import { Seller } from './seller';
import { Time } from '@angular/common';


export class DealsForToday{
    dealId:number;
    dealDiscount:number;
    dealStart:Date;
    dealEnd:Date;
    product:Product;
    dealEndsTime: Time;
    dealStartsTime: Time;
    seller:Seller;
    errorMessage:String;
    successMessage:String;
}
