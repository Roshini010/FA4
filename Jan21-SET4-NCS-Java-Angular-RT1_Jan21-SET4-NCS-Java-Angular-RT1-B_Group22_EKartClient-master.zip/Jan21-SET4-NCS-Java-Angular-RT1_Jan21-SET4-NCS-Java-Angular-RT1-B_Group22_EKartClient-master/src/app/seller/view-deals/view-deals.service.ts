import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { DealsForToday } from 'src/app/shared/models/deals';


/* View Deal */
@Injectable({
  providedIn: 'root'
})
export class ViewDealsService {

  constructor(private httpClient:HttpClient) { }

  getDeals(emailId,pageNo):Observable<DealsForToday[]>
  {
    const url=environment.DealsForTodayAPI+"/dealForToday/"+emailId+"/"+pageNo;
    return this.httpClient.get<DealsForToday[]>(url);
  }

/* Remove Deal */

  removeFromDeal(dealId):Observable<any[]>{
    const url=environment.DealsForTodayAPI+"/dealForToday/"+dealId;
  
    return this.httpClient.delete<any>(url);
  }
}
