import { TestBed } from '@angular/core/testing';

import { ViewDealsService } from './view-deals.service';

describe('ViewDealsService', () => {
  let service: ViewDealsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ViewDealsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
