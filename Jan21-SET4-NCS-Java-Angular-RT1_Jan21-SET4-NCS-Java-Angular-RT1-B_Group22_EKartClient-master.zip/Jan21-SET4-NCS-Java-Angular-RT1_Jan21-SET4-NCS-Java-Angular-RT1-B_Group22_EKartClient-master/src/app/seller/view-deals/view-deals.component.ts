import { Component, OnInit } from '@angular/core';
import { Seller } from 'src/app/shared/models/seller';
import { ViewDealsService } from './view-deals.service';
import { DealsForToday } from 'src/app/shared/models/deals';


@Component({
  selector: 'app-view-deals',
  templateUrl: './view-deals.component.html',
  styleUrls: ['./view-deals.component.css']
})
export class ViewDealsComponent implements OnInit {
  seller:Seller;
  pageNo:number=0;
  dealsForTodayList:DealsForToday[];
  addedDeal:DealsForToday;
  showDeal:boolean=false;
  display:boolean=true;
  errorMessage:string;
  successMessage:any;

  dealsListLength:number;

  dateOld:string;
  dateArr:string[];
  date:String;
  dmonth:String;
  dyear:String;
  dhour:String;
  dsec:String;
  

  constructor(private dealService:ViewDealsService) { }

  ngOnInit(): void {
    this.seller=JSON.parse(sessionStorage.getItem("seller"));

    this.dealService.getDeals(this.seller.emailId,this.pageNo).subscribe(
      dList=> {this.dealsForTodayList=dList;
              this.dealsListLength=this.dealsForTodayList.length;
              console.log(dList);
            }

    )
  }

  removeFromDeal(deal:DealsForToday){
    this.successMessage=null;
    this.errorMessage=null;

    this.dealService.removeFromDeal(deal).subscribe(
      dList=>{
        this.successMessage=dList;
        console.log(dList);
        this.ngOnInit();
      },
      error=>{
        console.log(error);
        this.errorMessage=error.error.text;
        this.ngOnInit();
      }
    )
  }

  setAddedDeal(deal:DealsForToday){
    if(this.showDeal== false){
      this.showDeal=true;
      this.display=false;
    }
    else{
      this.showDeal=false;
      this.display=true;
    }
    this.addedDeal=deal;
  }

  tobackPage(){
    this.display=true;
    this.showDeal=false;
  }

  toNextPage(){
    this.pageNo+=1;
    this.ngOnInit();
  }

  toPreviousPage(){
    this.pageNo-=1;
    this.ngOnInit();
  }

  isDealActive(deal:DealsForToday):boolean{
    let systemTime:Date= new Date();
    let dealEndD:Date= new Date(deal.dealEnd[0],deal.dealEnd[1]-1,deal.dealEnd[2],deal.dealEnd[3],deal.dealEnd[4],0);

    if(dealEndD<systemTime){
      return false;
    }
    return true;
  }

  dateTimeFormat(formatDateTime:Date):any{
    this.dateOld=formatDateTime.toString();
    this.dateArr=this.dateOld.split(",");
    this.date=this.dateArr[2];
    this.dmonth=this.dateArr[1];
    this.dyear=this.dateArr[0];
    this.dhour=this.dateArr[3];
    this.dsec=this.dateArr[4];

    return(this.date+"/"+this.dmonth+"/"+this.dyear+" "+this.dhour+":"+this.dsec);
    }

}
