import { Component, OnInit } from '@angular/core';
import { DealsForToday } from 'src/app/shared/models/deals';
import { Seller } from 'src/app/shared/models/seller';
import { Product } from 'src/app/shared/models/product';
import { DealsForTodayService } from './deals-for-today.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-deals-for-today',
  templateUrl: './deals-for-today.component.html',
  styleUrls: ['./deals-for-today.component.css']
})
export class DealsForTodayComponent implements OnInit {

  errorMessage: String;
  successMessage: String;

  productsNotOnDealList:Product[];
  productsListLength:number;
  productsToBeAdded:Product;
  addToDeal:DealsForToday;
  seller:Seller;
  pageNo:number=0;

  displayList:boolean=false;
  display:boolean=false;

  addProductToDealsForm:FormGroup

  
  
  constructor(private dealsForTodayService: DealsForTodayService, private formBuilder:FormBuilder) { }

  ngOnInit(): void {
    this.successMessage=null;
    this.seller= JSON.parse(sessionStorage.getItem("seller"));

    this.dealsForTodayService.productsNotonDeal(this.seller.emailId,this.pageNo).subscribe(
      pdList=>{this.productsNotOnDealList=pdList;
                this.productsListLength=this.productsNotOnDealList.length;},

      error=>{this.addToDeal.errorMessage= error.error.errorMessage;}
    )
    this.displayList=true;
    this.createdForm();
  }

  createdForm(){
    this.addProductToDealsForm = this.formBuilder.group({
      dealStartDate:["",[Validators.required]],
      dealEndDate:["",[Validators.required]],
      dealDiscount:["",[Validators.required, Validators.min(0.1), Validators.max(100)]]
    })
  }

  toPreviousPage(){
    this.pageNo-=1;
    this.ngOnInit();
  }

  toNextPage(){
    this.pageNo+=1;
    this.ngOnInit();
  }

  displayAddtoDeals(product:Product){
    this.display=true;
    this.displayList=false;
    this.productsToBeAdded=product;
    this.productsToBeAdded.sellerEmailId=this.seller.emailId;
  }

  back(){
    this.displayList=true;
    this.display=false;
  }

  addProductsToDeal(){
    this.successMessage=null;
    this.errorMessage=null;

    this.addToDeal=new DealsForToday();

    this.addToDeal.dealStart=this.addProductToDealsForm.value.dealStartDate;
    this.addToDeal.dealEnd=this.addProductToDealsForm.value.dealEndDate;
    this.addToDeal.dealDiscount=this.addProductToDealsForm.value.dealDiscount;

    this.addToDeal.product=this.productsToBeAdded;
    this.addToDeal.seller=this.seller;

    this.dealsForTodayService.addProductsToDeal(this.addToDeal).subscribe(
      success=>{
        console.log(success);
        this.successMessage=success.successMessage;
      },
      error=>{
        this.errorMessage=error.error.errorMessage;
      }
    )
  }

    
 
}