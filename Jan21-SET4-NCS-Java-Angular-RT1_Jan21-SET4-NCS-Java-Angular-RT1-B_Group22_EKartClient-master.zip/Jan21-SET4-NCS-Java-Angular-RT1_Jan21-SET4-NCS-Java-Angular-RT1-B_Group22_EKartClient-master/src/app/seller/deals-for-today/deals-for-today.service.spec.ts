import { TestBed } from '@angular/core/testing';

import { DealsForTodayService } from './deals-for-today.service';

describe('DealsForTodayService', () => {
  let service: DealsForTodayService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DealsForTodayService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
