import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DealsForToday } from 'src/app/shared/models/deals';
import { environment } from 'src/environments/environment';
import { Product } from 'src/app/shared/models/product';

@Injectable({
  providedIn: 'root'
})
export class DealsForTodayService {
  private headers = new HttpHeaders({ 'Content-type': 'application/json' });
 
  constructor(private http: HttpClient) { }
    productsNotonDeal(sellerEmailId: string, pageNo: number): Observable<Product[]>{
     const url = environment.DealsForTodayAPI + "/ProductsNotIndealForToday" + "/" +sellerEmailId + "/" + pageNo;
     return this.http.get<Product[]>(url);
   }

   addProductsToDeal(deal:DealsForToday): Observable<DealsForToday>{
    const url=environment.DealsForTodayAPI + "/dealForToday" ;
    return this.http.post<DealsForToday>(url,deal);
   }
 
 }
  